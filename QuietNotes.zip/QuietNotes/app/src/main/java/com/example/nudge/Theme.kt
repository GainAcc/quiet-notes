package com.example.nudge

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColors = lightColorScheme(
    primary = Color(0xFF00796B),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFB2DFDB),
    onPrimaryContainer = Color(0xFF00201C),
    background = Color(0xFFF7F8F8),
    onBackground = Color(0xFF1B1C1C),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1B1C1C),
    surfaceVariant = Color(0xFFE3EAE8),
    onSurfaceVariant = Color(0xFF55615E),
    outline = Color(0xFF73807D)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DB6AC),
    onPrimary = Color(0xFF003732),
    primaryContainer = Color(0xFF00504A),
    onPrimaryContainer = Color(0xFFB2DFDB),
    background = Color(0xFF111414),
    onBackground = Color(0xFFE1E3E2),
    surface = Color(0xFF1A1E1E),
    onSurface = Color(0xFFE1E3E2),
    surfaceVariant = Color(0xFF3B4947),
    onSurfaceVariant = Color(0xFFB4C0BD),
    outline = Color(0xFF899390)
)

/** mode: 0 = follow system, 1 = light, 2 = dark */
@Composable
fun NudgeTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val scheme = if (dark) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = scheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
