package com.example.nudge

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels

class MainActivity : ComponentActivity() {
    private val vm: MainVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handle(intent)
        setContent {
            NudgeTheme(vm.themeMode) { App(vm) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        // Catch up on anything that was due while the app was closed.
        Engine.processAll(this)
    }

    /** Tapping a notification opens that note. */
    private fun handle(i: Intent?) {
        val id = i?.getLongExtra("id", 0L) ?: 0L
        if (id != 0L) {
            vm.open(id)
            i?.removeExtra("id")
        }
    }
}
