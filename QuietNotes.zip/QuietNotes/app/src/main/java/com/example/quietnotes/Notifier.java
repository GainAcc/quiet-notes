package com.example.quietnotes;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

final class Notifier {
    private static final String CH = "notes";

    static int nid(long id) { return (int) (id ^ (id >>> 32)); }

    /** Posts the non-dismissible "New Notification" for this note. */
    static void show(Context c, Note n, boolean alert) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Notes", NotificationManager.IMPORTANCE_DEFAULT));
            b = new Notification.Builder(c, CH);
        } else {
            b = new Notification.Builder(c);
            if (alert) b.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE);
        }
        Intent open = new Intent(c, NoteActivity.class).putExtra("id", n.id);
        PendingIntent pi = TaskStackBuilder.create(c).addNextIntentWithParentStack(open)
                .getPendingIntent(nid(n.id), PendingIntent.FLAG_UPDATE_CURRENT);
        b.setSmallIcon(R.drawable.ic_notif)
                .setContentTitle("New Notification")
                .setContentIntent(pi)
                .setOngoing(true)       // cannot be swiped away
                .setAutoCancel(false);  // tapping it does not remove it
        nm.notify(nid(n.id), b.build());
    }

    static void clear(Context c, Note n) {
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(nid(n.id));
    }

    private static PendingIntent alarmPi(Context c, long id) {
        Intent i = new Intent(c, AlarmReceiver.class).putExtra("id", id);
        return PendingIntent.getBroadcast(c, nid(id), i, PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static void schedule(Context c, Note n) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, n.remindAt, alarmPi(c, n.id));
        else am.setExact(AlarmManager.RTC_WAKEUP, n.remindAt, alarmPi(c, n.id));
    }

    static void cancelAlarm(Context c, Note n) {
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(alarmPi(c, n.id));
    }
}
