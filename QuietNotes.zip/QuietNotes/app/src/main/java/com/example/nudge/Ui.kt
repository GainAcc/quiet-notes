@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.nudge

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.text.format.DateFormat
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.util.Calendar

@Composable
fun App(vm: MainVm) {
    val ctx = LocalContext.current
    var showHint by remember { mutableStateOf(Prefs.needsBatteryHint(ctx)) }

    BackHandler(enabled = vm.screen != Screen.Home) { vm.back(ctx) }

    when (vm.screen) {
        Screen.Home -> HomeScreen(vm)
        Screen.Settings -> SettingsScreen(vm)
        is Screen.Editor -> EditorScreen(vm)
    }

    if (showHint) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("Keep reminders reliable") },
            text = {
                Text(
                    "On Huawei phones, apps can be stopped in the background and miss reminders. " +
                        "Add Nudge to Protected apps:\nSettings > Advanced settings > Battery manager > Protected apps."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    Prefs.batteryHintDone(ctx)
                    showHint = false
                    Battery.open(ctx)
                }) { Text("Open settings") }
            },
            dismissButton = {
                TextButton(onClick = {
                    Prefs.batteryHintDone(ctx)
                    showHint = false
                }) { Text("Later") }
            }
        )
    }
}

@Composable
private fun barColors() =
    TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)

// ---------------------------------------------------------------- Home

@Composable
fun HomeScreen(vm: MainVm) {
    val notes by vm.notes.collectAsState(initial = emptyList())
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Nudge") },
                actions = {
                    IconButton(onClick = { vm.screen = Screen.Settings }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
                colors = barColors()
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { vm.openNew() }) {
                Icon(Icons.Default.Add, contentDescription = "New note")
            }
        }
    ) { pad ->
        if (notes.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pad), contentAlignment = Alignment.Center) {
                Text(
                    "No notes yet.\nTap + to add one.",
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(pad),
                contentPadding = PaddingValues(start = 12.dp, top = 8.dp, end = 12.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(notes, key = { it.id }) { n -> NoteCard(n) { vm.open(n.id) } }
            }
        }
    }
}

@Composable
private fun NoteCard(n: Note, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val status = statusOf(n)
    Card(
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = scheme.surface),
        elevation = CardDefaults.cardElevation(0.dp),
        border = BorderStroke(1.dp, scheme.surfaceVariant)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                n.text,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            if (status.isNotEmpty()) {
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (n.colorOn && n.active) {
                        Box(
                            Modifier.size(10.dp).background(
                                Color(ColorMath.color(n, System.currentTimeMillis())), CircleShape
                            )
                        )
                        Spacer(Modifier.width(8.dp))
                    }
                    Text(status, style = MaterialTheme.typography.labelMedium, color = scheme.primary)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Editor

@Composable
fun EditorScreen(vm: MainVm) {
    val ctx = LocalContext.current
    val f = vm.form
    val isNew = f.existing == null
    var confirmDelete by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isNew) "New note" else "Edit note") },
                navigationIcon = {
                    IconButton(onClick = { vm.back(ctx) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (!isNew) {
                        IconButton(onClick = { confirmDelete = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                    }
                },
                colors = barColors()
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = f.text,
                onValueChange = { f.text = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp),
                placeholder = { Text("Write your note...") }
            )

            if (isNew) {
                Choice(listOf("Urgent", "Surprise"), f.type) { f.type = it }
            } else {
                Label(if (f.type == TYPE_URGENT) "Urgent note" else "Surprise note")
            }
            Text(
                if (f.type == TYPE_URGENT) "Shows in the notification bar. Pin it now or set a reminder."
                else "Hidden from the list. It appears in the notification bar only at the time you set.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (f.type == TYPE_URGENT) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Color by deadline", style = MaterialTheme.typography.bodyLarge)
                        Text(
                            "The notification shifts from blue to red as the deadline gets close.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(checked = f.color, onCheckedChange = { f.color = it })
                }
                if (!f.color) {
                    Label("When")
                    Choice(listOf("Pin now", "At a time"), if (f.nowMode) 0 else 1) { f.nowMode = it == 0 }
                    if (!f.nowMode) {
                        TimeButton(f.timeMs, "Pick date and time") { f.timeMs = it }
                        RepeatPicker(f)
                    }
                } else {
                    Label("Starts")
                    Choice(listOf("Now", "At a time"), if (f.nowMode) 0 else 1) { f.nowMode = it == 0 }
                    if (!f.nowMode) TimeButton(f.timeMs, "Pick start") { f.timeMs = it }
                    Label("Deadline")
                    TimeButton(f.deadlineMs, "Pick deadline") { f.deadlineMs = it }
                }
            } else {
                Label("Appears at")
                TimeButton(f.timeMs, "Pick date and time") { f.timeMs = it }
                RepeatPicker(f)
            }

            val dirty = f.key() != f.initialKey
            val label = when {
                !isNew && !dirty && !f.forceApply -> "Save"
                f.type == TYPE_SURPRISE -> "Save"
                f.color -> "Start"
                f.nowMode -> "Pin now"
                else -> "Set reminder"
            }
            Button(
                onClick = { vm.save(ctx) },
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(top = 8.dp)
            ) { Text(label) }

            if (f.active) {
                val repeating = (f.existing?.repeatUnit ?: Repeat.NONE) != Repeat.NONE
                OutlinedButton(
                    onClick = { vm.clearActive(ctx) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        when {
                            f.type == TYPE_URGENT -> "Clear notification"
                            repeating -> "Hide until next time"
                            else -> "Done - delete note"
                        }
                    )
                }
            }
            Spacer(Modifier.size(24.dp))
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this note?") },
            text = { Text("This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    vm.delete(ctx)
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun Label(t: String) {
    Text(
        t,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp)
    )
}

@Composable
private fun Choice(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEachIndexed { i, s ->
            FilterChip(selected = selected == i, onClick = { onSelect(i) }, label = { Text(s) })
        }
    }
}

@Composable
private fun TimeButton(valueMs: Long, hint: String, onPick: (Long) -> Unit) {
    val ctx = LocalContext.current
    OutlinedButton(
        onClick = {
            val c = Calendar.getInstance()
            if (valueMs > 0) c.timeInMillis = valueMs
            DatePickerDialog(
                ctx,
                { _, y, m, d ->
                    TimePickerDialog(
                        ctx,
                        { _, h, min ->
                            val t = Calendar.getInstance()
                            t.set(y, m, d, h, min, 0)
                            t.set(Calendar.MILLISECOND, 0)
                            onPick(t.timeInMillis)
                        },
                        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), DateFormat.is24HourFormat(ctx)
                    ).show()
                },
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)
            ).show()
        },
        modifier = Modifier.fillMaxWidth()
    ) { Text(if (valueMs > 0) fmt(valueMs) else hint) }
}

@Composable
private fun RepeatPicker(f: Form) {
    val names = listOf("Does not repeat", "Daily", "Weekly", "Monthly", "Yearly", "Custom...")
    var open by remember { mutableStateOf(false) }
    Label("Repeat")
    Box {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text(names[f.repMode])
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            names.forEachIndexed { i, s ->
                DropdownMenuItem(text = { Text(s) }, onClick = {
                    f.repMode = i
                    open = false
                })
            }
        }
    }
    if (f.repMode == 5) {
        var unitOpen by remember { mutableStateOf(false) }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Every")
            OutlinedTextField(
                value = f.customN,
                onValueChange = { v -> if (v.length <= 4 && v.all { it.isDigit() }) f.customN = v },
                modifier = Modifier.width(96.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            Box {
                OutlinedButton(onClick = { unitOpen = true }) { Text(unitPlural(f.customUnit)) }
                DropdownMenu(expanded = unitOpen, onDismissRequest = { unitOpen = false }) {
                    for (u in 1..6) {
                        DropdownMenuItem(text = { Text(unitPlural(u)) }, onClick = {
                            f.customUnit = u
                            unitOpen = false
                        })
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Settings

@Composable
fun SettingsScreen(vm: MainVm) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<Backup.Parsed?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri, "wt")?.use {
                    it.write(Backup.export(ctx).toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(ctx, "Backup saved", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, "Could not save the backup", Toast.LENGTH_LONG).show()
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val json = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val p = Backup.parse(json)
                if (p == null) {
                    Toast.makeText(ctx, "This is not a Nudge backup file", Toast.LENGTH_LONG).show()
                } else {
                    pending = p
                }
            } catch (e: Exception) {
                Toast.makeText(ctx, "Could not read the file", Toast.LENGTH_LONG).show()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = { vm.back(ctx) }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = barColors()
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Label("Theme")
            listOf("System default" to 0, "Light" to 1, "Dark" to 2).forEach { (name, v) ->
                Row(
                    Modifier.fillMaxWidth().clickable { vm.setTheme(ctx, v) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = vm.themeMode == v, onClick = { vm.setTheme(ctx, v) })
                    Text(name)
                }
            }

            Label("Backup")
            Text(
                "A backup file holds all your notes, including hidden Surprise notes, and your settings. " +
                    "Use it to move to a new phone.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = { exportLauncher.launch("nudge-backup.json") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Export backup") }
            OutlinedButton(
                onClick = { importLauncher.launch(arrayOf("*/*")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Import backup") }

            Label("Reliability")
            OutlinedButton(
                onClick = { Battery.open(ctx) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Battery settings (Protected apps)") }
        }
    }

    val p = pending
    if (p != null) {
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Import ${p.notes.size} notes?") },
            text = {
                Text(
                    "Merge adds the notes that are not already here.\n" +
                        "Replace deletes everything on this phone first."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.importBackup(ctx, p, replace = false)
                    pending = null
                }) { Text("Merge") }
            },
            dismissButton = {
                TextButton(onClick = {
                    vm.importBackup(ctx, p, replace = true)
                    pending = null
                }) { Text("Replace all") }
            }
        )
    }
}
