package com.example.nudge

import java.util.Calendar

/** Repeat rules: every [every] x [unit]. Monthly/yearly keep the original day (clamped to month end). */
object Repeat {
    const val NONE = 0
    const val MINUTE = 1
    const val HOUR = 2
    const val DAY = 3
    const val WEEK = 4
    const val MONTH = 5
    const val YEAR = 6

    private const val H = 3_600_000L

    // Lower bounds used only to skip ahead quickly.
    private fun minStepMs(unit: Int): Long = when (unit) {
        MINUTE -> 60_000L
        HOUR -> H
        DAY -> 23 * H
        WEEK -> 7 * 23 * H
        MONTH -> 28 * 23 * H
        else -> 365 * 23 * H
    }

    private fun occurrence(anchor: Long, unit: Int, every: Int, k: Long): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = anchor
        val amount = (every.toLong() * k).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        when (unit) {
            MINUTE -> c.add(Calendar.MINUTE, amount)
            HOUR -> c.add(Calendar.HOUR_OF_DAY, amount)
            DAY -> c.add(Calendar.DAY_OF_YEAR, amount)
            WEEK -> c.add(Calendar.WEEK_OF_YEAR, amount)
            MONTH -> c.add(Calendar.MONTH, amount)
            YEAR -> c.add(Calendar.YEAR, amount)
        }
        return c.timeInMillis
    }

    /** First occurrence strictly after [now] (the anchor itself if it is still in the future). */
    fun nextAfter(anchor: Long, unit: Int, every: Int, now: Long): Long {
        if (unit == NONE) return 0L
        val e = maxOf(1, every)
        var k = maxOf(0L, (now - anchor) / (minStepMs(unit) * e) - 1)
        while (true) {
            val t = occurrence(anchor, unit, e, k)
            if (t > now) return t
            k++
        }
    }
}

/** Blue (far) to red (close). The number of steps scales with the length of the period. */
object ColorMath {
    private const val MAX_STEPS = 24

    private fun steps(n: Note): Int =
        ((n.deadlineAt - n.startAt) / 60_000L).coerceIn(1L, MAX_STEPS.toLong()).toInt()

    private fun stepLen(n: Note): Long =
        ((n.deadlineAt - n.startAt) / steps(n)).coerceAtLeast(1L)

    fun currentStep(n: Note, now: Long): Int =
        ((now - n.startAt) / stepLen(n)).coerceIn(0L, steps(n).toLong()).toInt()

    fun finished(n: Note, now: Long): Boolean = currentStep(n, now) >= steps(n)

    fun color(n: Note, now: Long): Int {
        val p = currentStep(n, now).toFloat() / steps(n)
        return android.graphics.Color.HSVToColor(floatArrayOf(210f * (1f - p), 0.75f, 0.9f))
    }

    /** Next moment the color changes; always strictly after [now]. */
    fun nextChange(n: Note, now: Long): Long {
        val len = stepLen(n)
        val s = maxOf(0L, (now - n.startAt) / len)
        return n.startAt + (s + 1) * len
    }
}
