package com.example.quietnotes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity {
    private List<Note> notes = new ArrayList<>();
    private BaseAdapter adapter;
    private View empty;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        ListView list = findViewById(R.id.list);
        empty = findViewById(R.id.empty);
        findViewById(R.id.fab).setOnClickListener(v -> startActivity(new Intent(this, NoteActivity.class)));
        adapter = new BaseAdapter() {
            public int getCount() { return notes.size(); }
            public Object getItem(int i) { return notes.get(i); }
            public long getItemId(int i) { return notes.get(i).id; }
            public View getView(int i, View v, ViewGroup parent) {
                if (v == null) v = getLayoutInflater().inflate(R.layout.item_note, parent, false);
                Note n = notes.get(i);
                ((TextView) v.findViewById(R.id.text)).setText(n.text);
                TextView s = v.findViewById(R.id.status);
                if (n.pinned) s.setText("Notification active");
                else if (n.remindAt > 0) s.setText("Reminder: " + DateFormat.format("EEE d MMM, HH:mm", n.remindAt));
                else s.setText("");
                s.setVisibility(s.length() == 0 ? View.GONE : View.VISIBLE);
                return v;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) ->
                startActivity(new Intent(this, NoteActivity.class).putExtra("id", notes.get(pos).id)));
    }

    @Override protected void onResume() {
        super.onResume();
        notes = Store.all(this);
        Collections.sort(notes, (a, b) -> Long.compare(b.id, a.id)); // newest first
        adapter.notifyDataSetChanged();
        empty.setVisibility(notes.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
