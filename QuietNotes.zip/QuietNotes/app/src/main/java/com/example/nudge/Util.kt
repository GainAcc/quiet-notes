package com.example.nudge

import android.content.Context
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("nudge_prefs", Context.MODE_PRIVATE)

    /** 0 = follow system, 1 = light, 2 = dark */
    fun theme(c: Context): Int = p(c).getInt("theme", 0)
    fun setTheme(c: Context, v: Int) = p(c).edit().putInt("theme", v).apply()

    fun needsBatteryHint(c: Context): Boolean {
        val m = Build.MANUFACTURER.lowercase()
        return (m.contains("huawei") || m.contains("honor")) && !p(c).getBoolean("hint_done", false)
    }
    fun batteryHintDone(c: Context) = p(c).edit().putBoolean("hint_done", true).apply()
}

fun fmt(ms: Long): String =
    SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault()).format(Date(ms))

fun unitName(u: Int): String = when (u) {
    Repeat.MINUTE -> "minute"
    Repeat.HOUR -> "hour"
    Repeat.DAY -> "day"
    Repeat.WEEK -> "week"
    Repeat.MONTH -> "month"
    else -> "year"
}

fun unitPlural(u: Int): String = unitName(u) + "s"

fun repeatLabel(unit: Int, every: Int): String =
    if (every == 1) {
        when (unit) {
            Repeat.DAY -> "daily"
            Repeat.WEEK -> "weekly"
            Repeat.MONTH -> "monthly"
            Repeat.YEAR -> "yearly"
            else -> "every " + unitName(unit)
        }
    } else "every $every ${unitPlural(unit)}"

/** One-line status shown under a note in the list. */
fun statusOf(n: Note): String {
    val parts = ArrayList<String>()
    if (n.colorOn) {
        if (n.active) parts.add("Deadline " + fmt(n.deadlineAt))
        else if (n.triggerAt > 0) parts.add("Starts " + fmt(n.triggerAt) + " · deadline " + fmt(n.deadlineAt))
    } else {
        if (n.active) parts.add("Notification active")
        if (n.triggerAt > 0) parts.add((if (n.active) "next " else "Reminder: ") + fmt(n.triggerAt))
    }
    if (n.repeatUnit != Repeat.NONE) parts.add("repeats " + repeatLabel(n.repeatUnit, n.repeatEvery))
    return parts.joinToString(" · ")
}

/** Backup file: every note (including hidden ones) plus app settings, as plain JSON. */
object Backup {
    class Parsed(val notes: List<Note>, val theme: Int?)

    fun export(c: Context): String {
        val arr = JSONArray()
        for (n in Db.get(c).dao().all()) {
            arr.put(
                JSONObject()
                    .put("id", n.id)
                    .put("text", n.text)
                    .put("type", n.type)
                    .put("active", n.active)
                    .put("triggerAt", n.triggerAt)
                    .put("anchorAt", n.anchorAt)
                    .put("repeatUnit", n.repeatUnit)
                    .put("repeatEvery", n.repeatEvery)
                    .put("colorOn", n.colorOn)
                    .put("startAt", n.startAt)
                    .put("deadlineAt", n.deadlineAt)
                    .put("createdAt", n.createdAt)
            )
        }
        return JSONObject()
            .put("app", "nudge")
            .put("version", 1)
            .put("exportedAt", System.currentTimeMillis())
            .put("settings", JSONObject().put("theme", Prefs.theme(c)))
            .put("notes", arr)
            .toString(2)
    }

    fun parse(json: String): Parsed? {
        return try {
            val root = JSONObject(json)
            if (root.optString("app") != "nudge") return null
            val arr = root.getJSONArray("notes")
            val list = ArrayList<Note>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    Note(
                        id = o.getLong("id"),
                        text = o.optString("text"),
                        type = o.optInt("type").coerceIn(0, 1),
                        active = o.optBoolean("active"),
                        triggerAt = o.optLong("triggerAt"),
                        anchorAt = o.optLong("anchorAt"),
                        repeatUnit = o.optInt("repeatUnit"),
                        repeatEvery = o.optInt("repeatEvery"),
                        colorOn = o.optBoolean("colorOn"),
                        startAt = o.optLong("startAt"),
                        deadlineAt = o.optLong("deadlineAt"),
                        createdAt = o.optLong("createdAt")
                    )
                )
            }
            val theme = root.optJSONObject("settings")?.optInt("theme", 0)
            Parsed(list, theme)
        } catch (e: Exception) {
            null
        }
    }

    /** Returns how many notes were added. Past reminders fire right away via processAll. */
    fun restore(c: Context, p: Parsed, replace: Boolean): Int {
        val dao = Db.get(c).dao()
        if (replace) {
            for (old in dao.all()) {
                Notifier.cancel(c, old.id)
                Scheduler.cancel(c, old.id)
            }
            dao.deleteAll()
            if (p.theme != null) Prefs.setTheme(c, p.theme)
        }
        var added = 0
        for (n in p.notes) {
            if (dao.get(n.id) == null) {
                dao.put(n)
                added++
            }
        }
        Engine.processAll(c)
        return added
    }
}
