package com.example.nudge

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.RemoteViews

object Notifier {
    private const val CH = "notes"

    fun nid(id: Long): Int = (id xor (id ushr 32)).toInt()

    /** Posts the blank, non-dismissible notification for a note. */
    fun show(c: Context, n: Note, alert: Boolean) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val b: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "Notes", NotificationManager.IMPORTANCE_DEFAULT)
            )
            b = Notification.Builder(c, CH)
        } else {
            b = Notification.Builder(c)
            if (alert) b.setDefaults(Notification.DEFAULT_SOUND or Notification.DEFAULT_VIBRATE)
        }
        val open = Intent(c, MainActivity::class.java)
            .putExtra("id", n.id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val pi = PendingIntent.getActivity(
            c, nid(n.id), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        b.setSmallIcon(R.drawable.ic_notif)
            .setContentIntent(pi)
            .setOngoing(true)
            .setAutoCancel(false)
            .setShowWhen(false)
            .setOnlyAlertOnce(!alert)

        if (n.colorOn) {
            val color = ColorMath.color(n, System.currentTimeMillis())
            val rv = RemoteViews(c.packageName, R.layout.notif_color)
            rv.setInt(R.id.bar, "setBackgroundColor", color)
            b.setStyle(Notification.DecoratedCustomViewStyle())
                .setCustomContentView(rv)
                .setColor(color)
        }
        if (alert) nm.cancel(nid(n.id)) // re-post so it alerts again
        nm.notify(nid(n.id), b.build())
    }

    fun cancel(c: Context, id: Long) {
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(nid(id))
    }
}

object Scheduler {
    private fun pi(c: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(
            c, Notifier.nid(id),
            Intent(c, AlarmReceiver::class.java).putExtra("id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    /** The next moment something must happen for this note, or 0 if nothing. */
    private fun nextEvent(n: Note, now: Long): Long {
        var t = Long.MAX_VALUE
        if (n.triggerAt > 0) t = n.triggerAt
        if (n.active && n.colorOn && !ColorMath.finished(n, now)) {
            t = minOf(t, ColorMath.nextChange(n, now))
        }
        return if (t == Long.MAX_VALUE) 0L else t
    }

    fun schedule(c: Context, n: Note) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val t = nextEvent(n, System.currentTimeMillis())
        if (t == 0L) {
            am.cancel(pi(c, n.id))
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(c, n.id))
        }
    }

    fun cancel(c: Context, id: Long) {
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, id))
    }
}

object Engine {
    /** Makes the notification and the alarm match the note's state. */
    fun apply(c: Context, n: Note, alert: Boolean) {
        if (n.active) Notifier.show(c, n, alert) else Notifier.cancel(c, n.id)
        Scheduler.schedule(c, n)
    }

    /** Idempotent: fires what is due, refreshes colors, re-arms the alarm. */
    fun process(c: Context, id: Long) {
        val dao = Db.get(c).dao()
        var n = dao.get(id) ?: return
        val now = System.currentTimeMillis()
        var alert = false
        if (n.triggerAt in 1..now) {
            val next = if (n.repeatUnit != Repeat.NONE)
                Repeat.nextAfter(n.anchorAt, n.repeatUnit, n.repeatEvery, now) else 0L
            n = n.copy(active = true, triggerAt = next)
            dao.put(n)
            alert = true
        }
        apply(c, n, alert)
    }

    fun processAll(c: Context) {
        for (n in Db.get(c).dao().all()) process(c, n.id)
    }

    fun remove(c: Context, id: Long) {
        Notifier.cancel(c, id)
        Scheduler.cancel(c, id)
        Db.get(c).dao().delete(id)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Engine.process(context, intent.getLongExtra("id", 0L))
    }
}

/** After reboot, app update, or clock/timezone change: restore notifications and alarms. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Engine.processAll(context)
    }
}

object Battery {
    /** Opens Huawei's Protected apps screen if possible, otherwise general settings. */
    fun open(c: Context) {
        val tries = listOf(
            Intent().setComponent(
                ComponentName(
                    "com.huawei.systemmanager",
                    "com.huawei.systemmanager.optimize.process.ProtectActivity"
                )
            ),
            Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(android.provider.Settings.ACTION_SETTINGS)
        )
        for (i in tries) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(i)
                return
            } catch (e: Exception) {
                // try the next one
            }
        }
    }
}
