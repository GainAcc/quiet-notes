package com.example.nudge

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

const val TYPE_URGENT = 0
const val TYPE_SURPRISE = 1

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey val id: Long,          // creation time in ms (unique)
    val text: String = "",
    val type: Int = TYPE_URGENT,
    val active: Boolean = false,       // notification is currently shown
    val triggerAt: Long = 0,           // next time the notification must appear (0 = none)
    val anchorAt: Long = 0,            // first / chosen time, base for repeating
    val repeatUnit: Int = 0,           // see Repeat
    val repeatEvery: Int = 0,
    val colorOn: Boolean = false,      // urgent only: colored by deadline
    val startAt: Long = 0,             // color: when coloring starts
    val deadlineAt: Long = 0,          // color: the deadline
    val createdAt: Long = 0
)

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes WHERE type = 0 ORDER BY id DESC")
    fun observeUrgent(): Flow<List<Note>>

    @Query("SELECT * FROM notes")
    fun all(): List<Note>

    @Query("SELECT * FROM notes WHERE id = :id")
    fun get(id: Long): Note?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun put(note: Note)

    @Query("DELETE FROM notes WHERE id = :id")
    fun delete(id: Long)

    @Query("DELETE FROM notes")
    fun deleteAll()
}

// Data is tiny, so simple main-thread queries keep alarms/receivers straightforward.
@Database(entities = [Note::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): NoteDao

    companion object {
        @Volatile private var inst: Db? = null
        fun get(c: Context): Db = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "nudge.db")
                .allowMainThreadQueries()
                .build()
                .also { inst = it }
        }
    }
}
