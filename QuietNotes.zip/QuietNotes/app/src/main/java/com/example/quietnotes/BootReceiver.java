package com.example.quietnotes;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** After reboot/update: bring back active notifications and re-arm reminders. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        long now = System.currentTimeMillis();
        for (Note n : Store.all(c)) {
            if (n.pinned) {
                Notifier.show(c, n, false);
            } else if (n.remindAt > now) {
                Notifier.schedule(c, n);
            } else if (n.remindAt > 0) { // reminder time passed while the phone was off
                n.pinned = true;
                n.remindAt = 0;
                Store.put(c, n);
                Notifier.show(c, n, true);
            }
        }
    }
}
