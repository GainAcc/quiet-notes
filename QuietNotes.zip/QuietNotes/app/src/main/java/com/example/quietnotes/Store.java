package com.example.quietnotes;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

class Note {
    long id;          // also the creation time
    String text = "";
    long remindAt;    // 0 = no reminder scheduled
    boolean pinned;   // true = notification is active
}

class Store {
    private static final String PREF = "notes", KEY = "all";

    static synchronized List<Note> all(Context c) {
        List<Note> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(c.getSharedPreferences(PREF, 0).getString(KEY, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Note n = new Note();
                n.id = o.getLong("id");
                n.text = o.optString("text");
                n.remindAt = o.optLong("at");
                n.pinned = o.optBoolean("pin");
                out.add(n);
            }
        } catch (JSONException ignored) { }
        return out;
    }

    static synchronized Note get(Context c, long id) {
        for (Note n : all(c)) if (n.id == id) return n;
        return null;
    }

    static synchronized void put(Context c, Note note) {
        List<Note> l = all(c);
        boolean found = false;
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).id == note.id) { l.set(i, note); found = true; }
        }
        if (!found) l.add(note);
        write(c, l);
    }

    static synchronized void delete(Context c, long id) {
        List<Note> l = all(c);
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).id == id) l.remove(i);
        write(c, l);
    }

    private static void write(Context c, List<Note> l) {
        JSONArray a = new JSONArray();
        try {
            for (Note n : l) {
                a.put(new JSONObject().put("id", n.id).put("text", n.text)
                        .put("at", n.remindAt).put("pin", n.pinned));
            }
        } catch (JSONException ignored) { }
        c.getSharedPreferences(PREF, 0).edit().putString(KEY, a.toString()).apply();
    }
}
