package com.example.quietnotes;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.util.Calendar;

public class NoteActivity extends Activity {
    private EditText et;
    private Button clear;
    private Note note;
    private boolean deleted;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_note);
        if (getActionBar() != null) getActionBar().setDisplayHomeAsUpEnabled(true);
        et = findViewById(R.id.et);
        clear = findViewById(R.id.clear);
        long id = getIntent().getLongExtra("id", 0);
        note = id != 0 ? Store.get(this, id) : null;
        if (note == null) { note = new Note(); note.id = System.currentTimeMillis(); }
        else et.setText(note.text);
        findViewById(R.id.pin).setOnClickListener(v -> pinNow());
        findViewById(R.id.remind).setOnClickListener(v -> pickTime());
        clear.setOnClickListener(v -> {
            if (!persist()) return;
            Notifier.clear(this, note);
            note.pinned = false;
            Store.put(this, note);
            refresh();
        });
    }

    @Override protected void onResume() { super.onResume(); refresh(); }
    @Override protected void onPause() { super.onPause(); persist(); }

    private void refresh() {
        Note cur = Store.get(this, note.id);
        clear.setVisibility(cur != null && cur.pinned ? View.VISIBLE : View.GONE);
    }

    /** Saves the text only (keeps pin/reminder state from storage). Silent. */
    private boolean persist() {
        if (deleted) return false;
        String t = et.getText().toString().trim();
        if (t.isEmpty()) return false;
        Note cur = Store.get(this, note.id);
        if (cur == null) cur = note;
        cur.text = t;
        Store.put(this, cur);
        note = cur;
        return true;
    }

    private boolean save() {
        boolean ok = persist();
        if (!ok) Toast.makeText(this, "Write something first", Toast.LENGTH_SHORT).show();
        return ok;
    }

    private void pinNow() {
        if (!save()) return;
        Notifier.cancelAlarm(this, note);
        note.remindAt = 0;
        note.pinned = true;
        Store.put(this, note);
        Notifier.show(this, note, true);
        finish();
    }

    private void pickTime() {
        if (!save()) return;
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, (dp, y, m, d) ->
                new TimePickerDialog(this, (tp, h, min) -> {
                    Calendar t = Calendar.getInstance();
                    t.set(y, m, d, h, min, 0);
                    t.set(Calendar.MILLISECOND, 0);
                    if (t.getTimeInMillis() <= System.currentTimeMillis()) {
                        Toast.makeText(this, "Pick a time in the future", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Notifier.clear(this, note);
                    note.pinned = false;
                    note.remindAt = t.getTimeInMillis();
                    Store.put(this, note);
                    Notifier.schedule(this, note);
                    Toast.makeText(this, "Reminder set", Toast.LENGTH_SHORT).show();
                    finish();
                }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), DateFormat.is24HourFormat(this)).show(),
                c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    @Override public boolean onCreateOptionsMenu(Menu m) {
        m.add(0, 1, 0, "Delete").setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        return true;
    }

    @Override public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) { finish(); return true; }
        if (item.getItemId() == 1) {
            deleted = true;
            Notifier.clear(this, note);
            Notifier.cancelAlarm(this, note);
            Store.delete(this, note.id);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
