package com.example.nudge

import android.app.Application
import android.content.Context
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.Flow

sealed interface Screen {
    data object Home : Screen
    data object Settings : Screen
    data class Editor(val id: Long) : Screen
}

/** Everything the editor screen edits. */
class Form {
    var existing: Note? = null
    var text by mutableStateOf("")
    var type by mutableIntStateOf(TYPE_URGENT)
    var color by mutableStateOf(false)
    var nowMode by mutableStateOf(true)      // urgent: pin now / start now
    var timeMs by mutableLongStateOf(0L)     // reminder time / surprise time / color start
    var deadlineMs by mutableLongStateOf(0L)
    var repMode by mutableIntStateOf(0)      // 0 none, 1 daily, 2 weekly, 3 monthly, 4 yearly, 5 custom
    var customN by mutableStateOf("1")
    var customUnit by mutableIntStateOf(Repeat.DAY)
    var active by mutableStateOf(false)      // note is currently in the notification bar
    var initialKey = ""
    var forceApply = false                   // idle plain note: the button must pin / schedule it

    fun key(): String = "$type|$color|$nowMode|$timeMs|$deadlineMs|$repMode|$customN|$customUnit"

    fun repeatPair(): Pair<Int, Int> = when (repMode) {
        0 -> Pair(Repeat.NONE, 0)
        1 -> Pair(Repeat.DAY, 1)
        2 -> Pair(Repeat.WEEK, 1)
        3 -> Pair(Repeat.MONTH, 1)
        4 -> Pair(Repeat.YEAR, 1)
        else -> Pair(customUnit, customN.toIntOrNull() ?: 0)
    }

    fun reset(n: Note?) {
        existing = n
        text = n?.text ?: ""
        type = n?.type ?: TYPE_URGENT
        color = n?.colorOn ?: false
        active = n?.active ?: false
        deadlineMs = n?.deadlineAt ?: 0L

        val u = n?.repeatUnit ?: Repeat.NONE
        val e = n?.repeatEvery ?: 0
        customN = "1"
        customUnit = Repeat.DAY
        repMode = when {
            u == Repeat.NONE -> 0
            e == 1 && u == Repeat.DAY -> 1
            e == 1 && u == Repeat.WEEK -> 2
            e == 1 && u == Repeat.MONTH -> 3
            e == 1 && u == Repeat.YEAR -> 4
            else -> {
                customN = e.toString()
                customUnit = u
                5
            }
        }

        if (n == null) {
            nowMode = true
            timeMs = 0L
        } else if (n.colorOn) {
            nowMode = false
            timeMs = n.startAt
        } else if (n.type == TYPE_SURPRISE) {
            nowMode = false
            timeMs = n.anchorAt
        } else if (n.anchorAt > 0) {
            nowMode = false
            timeMs = n.anchorAt
        } else {
            nowMode = true
            timeMs = 0L
        }
        initialKey = key()
        forceApply = n != null && n.type == TYPE_URGENT && !n.colorOn && !n.active && n.triggerAt == 0L
    }
}

class MainVm(app: Application) : AndroidViewModel(app) {
    private val dao = Db.get(app).dao()
    val notes: Flow<List<Note>> = dao.observeUrgent()
    var screen by mutableStateOf<Screen>(Screen.Home)
    var themeMode by mutableIntStateOf(Prefs.theme(app))
    val form = Form()

    private fun toast(c: Context, s: String) =
        Toast.makeText(c, s, Toast.LENGTH_LONG).show()

    private fun fail(c: Context, s: String): Boolean {
        toast(c, s)
        return false
    }

    private fun newId(): Long {
        var id = System.currentTimeMillis()
        while (dao.get(id) != null) id++
        return id
    }

    fun openNew() {
        form.reset(null)
        screen = Screen.Editor(0L)
    }

    fun open(id: Long) {
        val n = dao.get(id)
        if (n == null) {
            screen = Screen.Home
        } else {
            form.reset(n)
            screen = Screen.Editor(id)
        }
    }

    fun back(ctx: Context) {
        if (screen is Screen.Editor) autosave(ctx)
        screen = Screen.Home
    }

    /** Leaving the editor with Back keeps the text, never the schedule. */
    private fun autosave(ctx: Context) {
        val f = form
        val text = f.text.trim()
        if (text.isEmpty()) return
        val dirty = f.key() != f.initialKey
        val ex = f.existing
        if (ex != null) {
            val cur = dao.get(ex.id) ?: return
            if (text != cur.text) dao.put(cur.copy(text = text))
            if (dirty) toast(ctx, "Schedule changes were not applied. Use the button to apply them.")
        } else if (f.type == TYPE_URGENT) {
            dao.put(Note(id = newId(), text = text, type = TYPE_URGENT, createdAt = System.currentTimeMillis()))
            if (dirty) toast(ctx, "Saved as a plain note. Use the button to pin it or set a reminder.")
        } else {
            toast(ctx, "Surprise note not saved: it needs a time. Use Save.")
        }
    }

    fun save(ctx: Context): Boolean {
        val f = form
        val text = f.text.trim()
        if (text.isEmpty()) return fail(ctx, "Write something first")
        val now = System.currentTimeMillis()
        val ex = f.existing
        val cur = if (ex != null) dao.get(ex.id) else null
        if (ex != null && cur == null) {
            screen = Screen.Home
            return false
        }

        // Schedule untouched: only the text changes.
        if (cur != null && !f.forceApply && f.key() == f.initialKey) {
            dao.put(cur.copy(text = text))
            screen = Screen.Home
            return true
        }

        val (unit, every) = f.repeatPair()
        val timeBased = f.type == TYPE_SURPRISE || (!f.color && !f.nowMode)
        if (timeBased) {
            if (f.timeMs == 0L) return fail(ctx, "Pick a date and time")
            if (unit != Repeat.NONE && every !in 1..9999) return fail(ctx, "Enter a valid repeat number")
            if (unit == Repeat.NONE && f.timeMs <= now) return fail(ctx, "Pick a time in the future")
        }
        var start = 0L
        if (f.type == TYPE_URGENT && f.color) {
            if (!f.nowMode && f.timeMs == 0L) return fail(ctx, "Pick a start time")
            start = if (f.nowMode) now else f.timeMs
            if (f.deadlineMs == 0L) return fail(ctx, "Pick a deadline")
            if (f.deadlineMs <= start || f.deadlineMs <= now) {
                return fail(ctx, "The deadline must be in the future and after the start")
            }
        }

        val wasActive = cur?.active == true
        val base = cur ?: Note(id = newId(), type = f.type, createdAt = now)
        val firstTrigger = if (unit == Repeat.NONE) f.timeMs else Repeat.nextAfter(f.timeMs, unit, every, now)
        val n: Note = when {
            f.type == TYPE_SURPRISE -> base.copy(
                text = text, colorOn = false, active = false, anchorAt = f.timeMs,
                repeatUnit = unit, repeatEvery = every, startAt = 0L, deadlineAt = 0L,
                triggerAt = firstTrigger
            )
            f.color -> base.copy(
                text = text, colorOn = true, startAt = start, deadlineAt = f.deadlineMs,
                anchorAt = 0L, repeatUnit = Repeat.NONE, repeatEvery = 0,
                active = start <= now, triggerAt = if (start <= now) 0L else start
            )
            f.nowMode -> base.copy(
                text = text, colorOn = false, active = true, triggerAt = 0L, anchorAt = 0L,
                repeatUnit = Repeat.NONE, repeatEvery = 0, startAt = 0L, deadlineAt = 0L
            )
            else -> base.copy(
                text = text, colorOn = false, active = false, anchorAt = f.timeMs,
                repeatUnit = unit, repeatEvery = every, startAt = 0L, deadlineAt = 0L,
                triggerAt = firstTrigger
            )
        }
        dao.put(n)
        Engine.apply(ctx, n, n.active && !wasActive)

        toast(
            ctx, when {
                n.type == TYPE_SURPRISE -> "Saved. It stays hidden until " + fmt(n.triggerAt)
                n.active -> "Notification pinned"
                n.triggerAt > 0 -> "Reminder set for " + fmt(n.triggerAt)
                else -> "Saved"
            }
        )
        screen = Screen.Home
        return true
    }

    /** Urgent: clear the notification. Surprise: hide it (repeating) or finish it (one-time). */
    fun clearActive(ctx: Context) {
        val ex = form.existing ?: return
        val cur = dao.get(ex.id) ?: return
        if (cur.type == TYPE_SURPRISE && cur.repeatUnit == Repeat.NONE) {
            Engine.remove(ctx, cur.id)
        } else {
            val n = cur.copy(active = false)
            dao.put(n)
            Engine.apply(ctx, n, false)
        }
        screen = Screen.Home
    }

    fun delete(ctx: Context) {
        form.existing?.let { Engine.remove(ctx, it.id) }
        screen = Screen.Home
    }

    fun setTheme(ctx: Context, v: Int) {
        Prefs.setTheme(ctx, v)
        themeMode = v
    }

    fun importBackup(ctx: Context, p: Backup.Parsed, replace: Boolean) {
        val added = Backup.restore(ctx, p, replace)
        themeMode = Prefs.theme(ctx)
        toast(ctx, "Imported $added notes")
    }
}
