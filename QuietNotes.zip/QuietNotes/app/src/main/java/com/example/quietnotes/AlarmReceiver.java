package com.example.quietnotes;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        Note n = Store.get(c, i.getLongExtra("id", 0));
        if (n == null) return;
        n.pinned = true;
        n.remindAt = 0;
        Store.put(c, n);
        Notifier.show(c, n, true);
    }
}
